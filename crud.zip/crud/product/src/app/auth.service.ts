import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  allowUser = false;
  constructor(private http : HttpClient) { }
  signupurl = 'http://localhost/mautic_ci_product/index.php/welcome/signup';
  loginurl = 'http://localhost/mautic_ci_product/index.php/welcome/signin';
  userdetails='http://localhost/mautic_ci_product/index.php/welcome/loadusers';
  singleUser='http://localhost/mautic_ci_product/index.php/welcome/getuser';
  updateUser='http://localhost/mautic_ci_product/index.php/welcome/updateuser';
  singup(data){
    return this.http.post(this.signupurl,data);
  }

  login(data){
    return this.http.post(this.loginurl,data);
  }

  loadUser(){
    return this.http.get(this.userdetails);
  }
  isAuthenticated(data){
    this.allowUser =data;
  }
  getSingleUser(id){
    return this.http.post(this.singleUser,id);
  }
  updateUdata(data){
    return this.http.post(this.updateUser,data);
  }
}
