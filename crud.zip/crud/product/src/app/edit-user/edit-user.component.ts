import { Component, OnInit } from '@angular/core';
import { ActivatedRouteSnapshot, ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { FormGroup, FormControl } from '@angular/forms';
import { UserListComponent } from '../user-list/user-list.component';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  userId :number;
  userDetails ={
    id:'',
    name : '',
    email:'',
    gender:'',
    country:'',
    maritialStatus:null,
  }
  constructor(private route :ActivatedRoute,private auth:AuthService,private router:Router,private userComp :UserListComponent) { }

  ngOnInit() {
    this.userId = this.route.snapshot.params['id'];
    this.route.params.subscribe(
      (param)=>{
        this.userId = param['id'];
        this.getUser(this.userId);
      }
    );
  } 
  getUser(id){
    this.auth.getSingleUser(this.userId)
    .subscribe(
      (data) =>{
        this.userDetails.id = data[0].id;
        this.userDetails.name = data[0].name;
        this.userDetails.email = data[0].email;
        this.userDetails.gender = data[0].gender;
        this.userDetails.country = data[0].country;
        this.userDetails.maritialStatus = data[0].maritial_status==1 ? true : false;
        this.editForm.setValue({
          id : this.userDetails.id,
          name:this.userDetails.name,
          email:this.userDetails.email,
          gender:this.userDetails.gender,
          country:this.userDetails.country,
          maritialStatus:this.userDetails.maritialStatus,
        });
      }
    );
  }

editdata={
  id : '',
  name : '',
  email :'',
  gender :'',
  country :'',
  maritialStatus :null,
}

editForm=new FormGroup({
  id : new FormControl(null),
  name : new FormControl(null),
  email: new FormControl(null),
  gender: new FormControl(null),
  country: new FormControl(null),
  maritialStatus: new FormControl(null),
});
onedit(){
  this.editdata.id = this.editForm.value.id;
  this.editdata.name = this.editForm.value.name;
  this.editdata.email = this.editForm.value.email;
  this.editdata.gender = this.editForm.value.gender;
  this.editdata.country = this.editForm.value.country;
  this.editdata.maritialStatus = this.editForm.value.maritialStatus;
  this.auth.updateUdata(this.editdata)
  .subscribe(
    (data)=>{
      this.router.navigate(['/']);
  });
}
}
