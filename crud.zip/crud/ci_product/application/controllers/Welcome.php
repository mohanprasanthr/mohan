<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, Accept, Authorization, X-Request-With');
header('Access-Control-Allow-Credentials: true');
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('product');
		
		
	}
	 
	public function index()
	{
		//~ $this->signup();
		$this->load->view('welcome_message');
	}
	
	public function signup(){
		
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		if(!empty($request)){
			$data = array(
				'name' => (!empty($request->name) ? $request->name : ''),
				'email' => (!empty($request->email) ? $request->email : ''),
				'password' => (!empty($request->password) ? $request->password : ''),
				'gender' => (!empty($request->gender) ? $request->gender : ''),
				'country' => (!empty($request->country) ? $request->country : ''),
				'maritial_status' => (!empty($request->maritialStatus) ? $request->maritialStatus : ''),
			);
			$signup = $this->product->signup_insert($data);
			echo json_encode($signup);
		}
	}
	
	public function signin(){
		
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		if(!empty($request)){
			$data = array(
				'email' => (!empty($request->email) ? $request->email : ''),
				'password' => (!empty($request->password) ? $request->password : ''),
			);
			$signin = $this->product->signin($data);
			echo json_encode($signin);
		}
	}

	public function loadusers(){
	 	$values= $this->product->getusers();
		echo json_encode($values);
	}
	
	public function getuser(){
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		$get_user_data = $this->product->getsingleuser($request);
		echo json_encode($get_user_data);	
	}

	public function updateuser(){
		
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);

		if(!empty($request)){
			$data = array(
				'name' => (!empty($request->name) ? $request->name : ''),
				'email' => (!empty($request->email) ? $request->email : ''),
				'gender' => (!empty($request->gender) ? $request->gender : ''),
				'country' => (!empty($request->country) ? $request->country : ''),
				'maritial_status' => (!empty($request->maritialStatus) ? $request->maritialStatus : ''),
				 
			);
			$signup = $this->product->signup_update($request->id,$data);
			echo json_encode($signup);
		}
	}
}
